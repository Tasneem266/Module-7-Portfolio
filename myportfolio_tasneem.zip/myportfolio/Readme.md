Projects overview :

[20260823_195641_Portfolio_project overview & structure.pdf](assets/20260823_195641_Portfolio_project overview & structure.pdf)

Some snaps of the project : 

![](assets/20260823_195826_Screenshot_2026-08-23 190457.png)

![](assets/20260823_195826_Screenshot_2026-08-23 190256.png)

![](assets/20260823_195826_Screenshot_2026-08-23 190715.png)

![](assets/20260823_195826_Screenshot_2026-08-23 190831.png)

![](assets/20260823_195826_Screenshot_2026-08-23 190936.png)

![](assets/20260823_195826_Screenshot_2026-08-23 193728.png)

![](assets/20260823_195826_Screenshot_2026-08-23 193920.png)

![](assets/20260823_195826_Screenshot_2026-08-23 194241.png)

![](assets/20260823_195826_Screenshot_2026-08-23 194033.png)
