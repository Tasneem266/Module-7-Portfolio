from django.contrib import admin

from .models import Project

# Register your models here.

@admin.register(Project)
class ProjectAdmin(admin.ModelAdmin):
    list_display = ('title', 'technology_used', 'created_at')
    search_fields = ('title', 'technology_used')
    list_filter = ('technology_used',)

# admin.site.register(Project, ProjectAdmin)


