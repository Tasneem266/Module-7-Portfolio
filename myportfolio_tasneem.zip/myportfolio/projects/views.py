from django.shortcuts import render, get_object_or_404

from .models import Project

# Create your views here.

def home(request):
    context = {
        'name': 'Tasneem',
        'bio': 'I am a Learner. Love to learn at every phase.',
        'skills': ['C', 'Python', 'Java', 'HTML', 'MySQL'],
    }
    return render(request, 'projects/home.html', context)

def projects_list(request):
    projects = Project.objects.all()
    return render(request, 'projects/projects.html', {'projects': projects})

def project_detail(request, project_id):
    project = get_object_or_404(Project, id=project_id)
    return render(request, 'projects/project_detail.html', {'project': project})
